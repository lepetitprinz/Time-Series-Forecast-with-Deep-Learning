import config

import os

from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import LSTM, Dense, Input, BatchNormalization
from tensorflow.keras.layers import RepeatVector, TimeDistributed
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.layers import concatenate, multiply, dot
from tensorflow.keras.utils import plot_model


class Models(object):
    def __init__(self, n_hidden, n_features, window_input, window_output):
        self.n_features = n_features
        self.window_input = window_input
        self.window_output = window_output

        # Model Hyper-parameters
        self.n_hidden = n_hidden    # Seq to Seq Model Units
        self.activation = 'relu'    # Activation Function
        self.dropout = 0.1    # Dropout rate
        self.recurrent_dropout = 0.1
        self.momentum = 0.99    # Batch Normalization hyper-parameters
        self.lr = 0.001    # Learning Rate

        # Training hyper-parameters
        self.validation_split = 0.2
        self.batch_size = 64

    #########################
    # Time Series LSTM Model
    #########################
    def vanilla(self) -> Model:
        # define vanilla LSTM model
        # n time-steps to one time-step
        # Many-to-one model
        model = Sequential()
        model.add(LSTM(32, activation=self.activation, input_shape=(self.window_input, self.n_features),
                       return_sequences=True))
        model.add(LSTM(16, activation=self.activation, return_sequences=True))
        model.add(LSTM(8, activation=self.activation, return_sequences=False))
        model.add(Dense(1))
        optimizer = Adam(lr=self.lr, clipnorm=1)
        model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])

        return model

    def stacked(self) -> Model:
        # define stacked LSTM  model
        # Multi variate to ta rget
        # n time-steps to n time-steps
        model = Sequential()
        model.add(LSTM(32, activation=self.activation, input_shape=(self.window_input, self.n_features),
                       return_sequences=True))
        model.add(LSTM(16, activation=self.activation, return_sequences=True))
        model.add(LSTM(8, activation=self.activation, return_sequences=True))
        model.add(TimeDistributed(Dense(1)))
        optimizer = Adam(lr=self.lr, clipnorm=1)
        model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])

        return model

    def encoder_decoder(self) -> Model:
        # define encoder-decoder LSTM model
        # Many-to-one model
        model = Sequential()
        model.add(LSTM(64, activation=self.activation, input_shape=(self.window_input, self.n_features),
                       return_sequences=True))
        model.add(LSTM(32, activation=self.activation, return_sequences=False))
        model.add(RepeatVector(self.window_input))
        model.add(LSTM(32, activation=self.activation, return_sequences=True))
        model.add(LSTM(64, activation=self.activation, return_sequences=True))
        model.add(TimeDistributed(Dense(self.n_features)))
        optimizer = Adam(lr=self.lr, clipnorm=1)
        model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])
        print(model.summary())

        return model

    def seq2seq(self) -> Model:
        """
        Sequence to sequence model
        # Multivariate to target
        # m time-steps to n time-steps
        :return:
        """
        # define sequence to sequence LSTM model
        input_train = Input(shape=(self.window_input, self.n_features))
        output_train = Input(shape=(self.window_output, self.n_features))

        # Encoder LSTM
        encoder_last_h1, encoder_last_h2, encoder_last_c = LSTM(
            self.n_hidden, activation=self.activation,
            dropout=self.dropout, recurrent_dropout=self.recurrent_dropout,
            return_sequences=False, return_state=True)(input_train)

        # Batch normalization
        encoder_last_h1 = BatchNormalization(momentum=self.momentum)(encoder_last_h1)
        encoder_last_c = BatchNormalization(momentum=self.momentum)(encoder_last_c)

        # Decoder LSTM
        decoder = RepeatVector(output_train.shape[1])(encoder_last_h1)
        decoder = LSTM(self.n_hidden, activation=self.activation, dropout=self.dropout,
                       recurrent_dropout=self.recurrent_dropout, return_state=False,
                       return_sequences=True)(decoder, initial_state=[encoder_last_h1, encoder_last_c])
        out = TimeDistributed(Dense(1))(decoder)

        model = Model(inputs=input_train, outputs=out)
        optimizer = Adam(lr=self.lr, clipnorm=1)
        model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])
        model.summary()

        return model

    def train(self, model: Model, x_input_train, x_output_train, epochs: int, save_nm: str):
        # define early stopping
        early_stopping = EarlyStopping(monitor='val_loss', mode='min', patience=10)
        history = model.fit(x_input_train, x_output_train, validation_split=self.validation_split,
                            epochs=epochs, batch_size=self.batch_size, verbose=1, callbacks=[early_stopping])

        # save model
        model.save(os.path.join(config.SAVE_DIR, save_nm + "h5"))

        return history

